# glizzy-60-hidden-jst

JST version of https://github.com/glizzy-goblin/glizzy-60

Only h60 support with this version of the board :( 

19.1mm front height (18.5 from front lip), 6 deg

Weight screws: (m3 x 4mm) https://www.mcmaster.com/93395A196/

DB Screws: (m2 x 3mm) https://www.mcmaster.com/92000A010/

All DB screw holes go through, two of the weight holes go through

![pic](https://i.imgur.com/jc82Gsl.png)

disclaimer, this specific design has not been tested, but its based off of existing designs. use at your own risk
